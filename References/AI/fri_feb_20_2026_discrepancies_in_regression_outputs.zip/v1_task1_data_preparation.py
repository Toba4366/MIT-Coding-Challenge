# IMPORTANT: Fix convention - convert all to Foreign Currency per USD
# DEXUSAL, DEXUSEU, DEXUSUK are USD per foreign currency, need to invert
for curr in ['AUD', 'EUR', 'GBP']:
    fx[curr] = 1 / fx[curr]

# Calculate daily changes (in log returns for percentages)
fx[f'd_{curr}'] = np.log(fx[curr] / fx[curr].shift(1)) * 100  # in percent