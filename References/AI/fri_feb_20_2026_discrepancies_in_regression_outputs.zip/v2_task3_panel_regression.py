# CONVENTION FIX: Flip sign so positive = foreign currency appreciation ("spot return")
# Raw d_e = Δlog(foreign/USD), so positive = USD appreciation = foreign depreciation
# We want: positive = foreign appreciation, matching Antolín-Díaz et al. (2023)
panel_long['d_e'] = -panel_long['d_e']