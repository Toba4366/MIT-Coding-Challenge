# The dependent variable is the spot return r_{i,t} = -Δlog(e_{i,t}),
# so r > 0 indicates foreign appreciation (USD depreciation).