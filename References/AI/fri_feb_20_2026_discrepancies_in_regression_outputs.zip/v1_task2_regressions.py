# Scale STMT to basis points for interpretability
merged['STMT_bps'] = merged['STMT'] * 100